from .admin import register_all_models_of_app, register_all_fields_of_model

__all__ = ["register_all_models_of_app", "register_all_fields_of_model"]